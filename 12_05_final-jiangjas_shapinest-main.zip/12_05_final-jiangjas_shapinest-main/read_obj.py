import enum
from tempfile import tempdir
from numpy import poly
from matrix import new_matrix
from draw import *
def drawSquare( polygons, x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3):
    # mdl stores vertices for squares in counter clock wise order
    # this generates two triangles from this square with vertices going counter clock wise
    add_polygon(polygons, x0, y0, z0, x1, y1, z1, x3, y3, z3)
    add_polygon(polygons, x1, y1, z1, x2, y2, z2, x3, y3, z3)

def readobj(polygons, filename):
    with open(filename, "r") as file:
        # stores vertices as (x, y, z)
        mdl_vertices = []
        # stores normals as (x, y, z)
        mdl_normals = []
        mdl_center_normals = []
        counting_normals = True
        cur_line = 0
        while True:
            cur_line+= 1
            line = file.readline()
            if line == "" or line == None:
                break
            line = line.strip()

            args = line.split()
            if len(args) < 1 or args[0] == "#":
                continue
            command = args[0]
            # it takes literal days for my pc to figure out all these normals so ig i am going to code the vector normal part while it complies
            if (command == "v"):
                mdl_vertices.append( (float(args[1]), float(args[2]), float(args[3])) )
            if (command == "vn"):
                mdl_normals.append( (float(args[1]), float(args[2]), float(args[3])) )
            if (command == 'f'):
                normalvaluesum = [0, 0, 0]
                normal_counter = 0
                tmp_points = []
                for i, item in enumerate(args[1:]):
                    vertex = item.split('/')
                    # first int in slash seperated ints in obj represents vertices
                    tmp_points.append(vertex[0])
                    # second int represents vn adding it to sum to create average
                    if (len(vertex) > 2 and counting_normals):
                        for __i, __item in enumerate(mdl_normals[int(vertex[2]) -1]):
                            normal_counter += 1
                            normalvaluesum[__i] += __item
                for i, item in enumerate(tmp_points):
                    tmp_points[i] = int(item)
                if (len(tmp_points) == 4):
                    if (normal_counter == 4 and counting_normals):
                        normalvaluesum = [i/4 for i in normalvaluesum]
                        mdl_center_normals.append(normalvaluesum)
                    else:
                        counting_normals= False
                    (x0, y0, z0), (x1, y1, z1), (x2, y2, z2), (x3, y3, z3) = [mdl_vertices[i-1] for i in tmp_points]
                    drawSquare(polygons, x0, y0, z0, x1, y1, z1, x2, y2, z2, x3, y3, z3)
                elif (len(tmp_points) == 3):
                    if (normal_counter == 3 and counting_normals):
                        normalvaluesum = [i/3 for i in normalvaluesum]
                        mdl_center_normals.append(normalvaluesum)
                    else:
                        counting_normals = False
                    (x0, y0, z0), (x1, y1, z1), (x2, y2, z2) = [mdl_vertices[i-1] for i in tmp_points]
                    add_polygon(polygons, x0, y0, z0, x1, y1, z1, x2, y2, z2)
        if (not counting_normals):
            mdl_center_normals = None
        return mdl_center_normals