from tracemalloc import start
from PIL import Image
import imageio
import glob
from copy import deepcopy
import math

from numpy import block
#constants
XRES = 500
YRES = 500
MAX_COLOR = 255
RED = 0
GREEN = 1
BLUE = 2

DEFAULT_COLOR = [255, 255, 255]

def new_screen( width = XRES, height = YRES ):
    screen = []
    for y in range( height ):
        row = []
        screen.append( row )
        for x in range( width ):
            screen[y].append( DEFAULT_COLOR[:] )
    return screen

def new_zbuffer( width = XRES, height = YRES ):
    zb = []
    for y in range( height ):
        row = [ float('-inf') for x in range(width) ]
        zb.append( row )
    return zb
def new_tbuffer( width = XRES, height = YRES ):
    zb = []
    for y in range( height ):
        row = [ {} for x in range(width) ]
        zb.append( row )
    return zb

def calcScreen (screen, solid_screen, zbuffer, tbuffer, x, y):
    ordered_percentages = []
    for key, value in tbuffer[y][x].items():
        if (value[0] == None):
            continue
        if (value[1] == None):
            if (math.isinf(zbuffer[y][x]) and zbuffer[y][x] < 0):
                # print("warning: skipped over transparnet object: no end of transparent object found")
                continue
            value[1] = zbuffer[y][x], value[0][1], value[0][2]
        if (value[0][0] < zbuffer[y][x]):
            tbuffer[y][x].pop(key)
            continue
        if (value[1][0] < zbuffer[y][x]):
            value[1] = zbuffer[y][x], value[0][1], value[0][2]

        thickness = (value[0][0] - value[1][0])
        # doing an approximation of lighting to conserve speed, just preforming a geometric summation for each object
        # then ordering it by starting value
        tconstant = value[0][1] # % of light that gets blocked
        percentage = (tconstant*(1-(tconstant**thickness))) / (1-tconstant)
        # print(f"thickness: {thickness}, tconstant: {tconstant} percentage: {percentage}")
        ordered_percentages.append((value[0][0], percentage))
    ordered_percentages = sorted(ordered_percentages, key=lambda x: x[0] )
    light_left = 1
    final_color = [0, 0, 0]
    for i in ordered_percentages:
        light_blocked = i[1]
        light_through = 1 - light_blocked
        weight = light_blocked * light_left
        # blend the color found at the two ends of object
        if value[0][2] == value[1][2]:
            trans_color = value[0][2]
        else:
            trans_color = list(map(lambda x,y: ((x+y)/2) * weight ,value[0][2],value[1][2]))
        for k, item in enumerate(final_color):
            final_color[k] += trans_color[k]
        light_left *= light_through
    # remaining light gets picked up by solid_screen
    for i, item in enumerate(final_color):
        final_color[i] = int((solid_screen[y][x][i] * light_left) + item)
        if (final_color[i] < 0): 
            final_color[i] = 0
        if (final_color[i] > 255):
            final_color[i] = 255
    # print(f"y: {y}, x: {x}, finalcolor = {final_color}")
    screen[y][x] = final_color[:]
    pass

def edit_tbuffer(screen, solid_screen, zbuffer, tbuffer, color, x, y, z, trans_details):
    object = trans_details["object"]
    trans_unit = trans_details["trans_percentage"] # how much light is blocked from z index to z index
    start_end = trans_details["start_end"] # wether start end
    # store transpancy data from furthest away, to closest
    trans_pos_data= [z, trans_unit, color]
    # start = 0, end = 1
    if (object not in tbuffer[y][x]):
        tbuffer[y][x][object] = [None, None]

    if tbuffer[y][x][object][start_end] != None:
        can_replace = z > tbuffer[y][x][object][start_end][0]
        if (start_end == 1):
            can_replace = not can_replace
        if (not can_replace):
            return
    tbuffer[y][x][object][start_end] = deepcopy(trans_pos_data)
    calcScreen(screen, solid_screen, zbuffer, tbuffer, x, y)

def plot( screen, solid_screen, zbuffer,tbuffer, color, x, y, z, trans_details = False ):
    newy = YRES - 1 - y
    z = int((z * 1000)) / 1000.0
    if ( x >= 0 and x < XRES and newy >= 0 and newy < YRES and zbuffer[newy][x] <= z):
        if (trans_details != None):
            edit_tbuffer( screen, solid_screen, zbuffer,tbuffer, color, x, newy, z, trans_details)
            return


        solid_screen[newy][x] = color[:]
        zbuffer[newy][x] = z
        calcScreen(screen, solid_screen, zbuffer, tbuffer, x, newy)

def clear_screen( screen ):
    for y in range( len(screen) ):
        for x in range( len(screen[y]) ):
            screen[y][x] = DEFAULT_COLOR[:]

def clear_zbuffer( zb ):
    for y in range( len(zb) ):
        for x in range( len(zb[y]) ):
            zb[y][x] = float('-inf')

def save_ppm( screen, fname ):
    f = open( fname, 'wb' )
    ppm = 'P6\n' + str(len(screen[0])) +' '+ str(len(screen)) +' '+ str(MAX_COLOR) +'\n'
    f.write(ppm.encode())
    for y in range( len(screen) ):
        for x in range( len(screen[y]) ):
            pixel = screen[y][x]
            f.write( bytes(pixel) )
    f.close()

def save_ppm_ascii( screen, fname ):
    f = open( fname, 'w' )
    ppm = 'P3\n' + str(len(screen[0])) +' '+ str(len(screen)) +' '+ str(MAX_COLOR) +'\n'
    for y in range( len(screen) ):
        row = ''
        for x in range( len(screen[y]) ):
            pixel = screen[y][x]
            row+= str( pixel[ RED ] ) + ' '
            row+= str( pixel[ GREEN ] ) + ' '
            row+= str( pixel[ BLUE ] ) + ' '
        ppm+= row + '\n'
    f.write( ppm )
    f.close()

def save_extension( screen, fname ):
    img = Image.new('RGB', (len(screen[0]), len(screen)))

    pixels = []
    for row in screen:
        for pixel in row:
            pixels.append( tuple(pixel) )

    img.putdata(pixels)
    img.save(fname, 'PNG')

def display( screen ):
    img = Image.new('RGB', (len(screen[0]), len(screen)))

    pixels = []
    for row in screen:
        for pixel in row:
            pixels.append( tuple(pixel) )

    img.putdata(pixels)
    img.show()


def make_animation( name ):
    filenames = glob.glob("anim/" + name + "*");
    filenames = sorted(filenames)
    print(filenames)
    images = []
    for filename in filenames:
        images.append(imageio.imread(filename))
    imageio.mimsave(name+".gif", images, fps=30)
