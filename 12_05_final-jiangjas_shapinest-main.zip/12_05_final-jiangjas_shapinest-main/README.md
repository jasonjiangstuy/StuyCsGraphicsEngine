# Graphics Final Project
### Name: Jason Jiang
### Partner name: Esteak Shapin
### Class Period: 5
---
## New Graphics Engine Features

goals:
transparent objects
create object from obj file

stretch goals:
other water graphics:
refraction, reflection

---
## The Details
end goal: create a fish tank picture/gif that demonstrates
our additions to the graphics engine

transparent objects:
create new objects list that hold transparent object list
create transparent buffer that has piece wise function 
for how a pixel would be modified if it was at that particular x, y,z
after we calculate the colors of each of the pixels on the
screen buffer, modify each pixel using the transparent buffer

transparent objects will have all properties of polygons and an additional transparent
percentage

refractions... 
reflection...

expecting to use normal of the light, normal of the transparent surface to modfiy something


